﻿
$files = Get-ChildItem -Path (give the path to the folder where files exists)
$filename = $files.name
$results = @()
foreach($file in $filename){
$pattren = Get-Content C:\Users\kared\desktop\testing\$file | Select-String -Pattern createdate, \<fiscal
$obj = New-Object -TypeName psobject
$obj | Add-Member -MemberType NoteProperty -Name FileName -Value $file
$pattren[0] -match "(?'timestamp'\d+\-\d+\-\d+\w+\:\d+\:\d+\.\d+\-\d+\:\d+)" | Out-Null
$obj | Add-Member -MemberType NoteProperty -Name TimeStamp -Value $Matches.timestamp
$pattren[1] -match "fis\-\w+\.tif" | Out-Null
$obj | Add-Member -MemberType NoteProperty -Name Name -Value $Matches[0]
$obj
}
