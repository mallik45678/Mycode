﻿Param(
 [String]$computername,
 [String]$logname

 )
 foreach($comp in $computername)

{
     
    Get-EventLog -ComputerName $comp -LogName $logname -Newest 5 | Format-table
      
       
 
 }

