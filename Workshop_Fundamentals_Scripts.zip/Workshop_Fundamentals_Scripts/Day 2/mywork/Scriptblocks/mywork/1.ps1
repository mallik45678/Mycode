﻿Param($computer) 
&{
get-service -ComputerName $computer
Get-Process -ComputerName $computer

}


