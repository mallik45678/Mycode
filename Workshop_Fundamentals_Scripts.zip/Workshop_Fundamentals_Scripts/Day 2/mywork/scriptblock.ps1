
Param([int]$value1 , [int]$value2) {write-host "$value1", "$value2"
}