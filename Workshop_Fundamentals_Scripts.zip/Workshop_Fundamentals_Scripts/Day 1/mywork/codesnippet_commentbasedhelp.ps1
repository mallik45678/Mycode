﻿New-IseSnippet -Title Comment-BasedHelp -Description "A template for comment-based help." -Text "<# 
.SYNOPSIS
.DESCRIPTION                                                                                                                          
.PARAMETER  <Parameter-Name>                                                                                                          
.INPUTS                                                                                                                               
.OUTPUTS                                                                                                                              
.EXAMPLE                                                                                                                              
.LINK                                                                                                                            
#>" 
























#Get-IseSnippet | remove-item