﻿FUnction Get-service{

get-process

}

Get-Service